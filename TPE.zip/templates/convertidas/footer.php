<footer>

	<section class="logo">
		
		<a href="index"> <img src="/includes/img/logo.png" alt="inicio" /></a>
		
	</section>
	
	<section id="developer">
	
		<p> Desarrollado por <span>BlasM</span> </p>

	</section>

</footer>