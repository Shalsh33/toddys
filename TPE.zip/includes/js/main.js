// JavaScript Document
import navScript from './scripts.js';

document.addEventListener("DOMContentLoaded", (e) =>{
	navScript();
});

